export { default as HomePage } from './HomePage';
export { default as AboutPage } from './AboutPage';
export { default as ProductsPage } from './ProductsPage';
export { default as ServicesPage } from './ServicesPage';
export { default as ContactPage } from './ContactPage';
